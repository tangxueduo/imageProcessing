import numpy as np
import SimpleITK as sitk
from CPREngine.Tools import type_base as toty, utils as tout
from typing import Optional, Union

class ProbeRender:
    def __init__(
            self,
            centerline,
            image_data: sitk.Image,
            volume_type: str = "image",
            interpolator: Union[None, str] = None,
            image_spacing: float = None,
            output_shape: int = None,
            default_value: Optional[toty.Numeric] = None,
    ):
        self.centerline = centerline
        self.image_data = image_data
        self.volume_type = volume_type
        self.image_spacing = (
            [0.2, 0.2] if image_spacing is None else tout.array_polyfiller(image_spacing)
        )

        self.output_shape = (
            [64, 64] if output_shape is None else tout.array_polyfiller(output_shape)
        )

        # 插值方式
        if interpolator is None:
            if self.volume_type == "mask":
                self.interpolator = "nearest"
                self.sitk_interpolator = sitk.sitkNearestNeighbor
            else:
                self.interpolator = "linear"
                self.sitk_interpolator = sitk.sitkLinear
        else:
            self.interpolator = interpolator
            self.sitk_interpolator = self._sitk_interpolator_lut[interpolator]

        # 默认值
        if default_value is None:
            if self.volume_type == "mask":
                self.default_value = 0
            else:
                self.default_value = -1024
        else:
            self.default_value = default_value

    # 探针出图
    def Probe(
            self,
            return_numpy_array: bool = False,
            squeeze_d_axis: bool = True,
    ):
        orgs, dirs, spc = self._getStraightenSliceProps()
        if len(self.output_shape) == 2:
            output_shape = tuple(self.output_shape) + (1,)
        else:
            output_shape = (self.output_shape[0], self.output_shape[1], 1)
        spc = np.diag(spc)
        length = orgs.shape[0]
        probe_images = []
        for index in np.arange(0, length):
            image = self._resample(
                transform=sitk.AffineTransform(3),
                origin=orgs[index],
                direction=dirs[index],
                nominal_spacing=spc,
                result_spacing=spc,
                size=output_shape,
                default_value=self.default_value,
                return_numpy_array=return_numpy_array,
                squeeze_d_axis=squeeze_d_axis,
            )
            probe_images.append(image)

        return probe_images

    # 计算根据output_shape计算图像起始点在三维中的位置（orgs）
    # 每个中心线点的副法线、法线、切线矩阵（dirs）
    # 采样间距（spacing）
    def _getStraightenSliceProps(self):
        y = self.centerline['y']
        B = self.centerline['B']
        N = self.centerline['N']
        T = self.centerline['T']
        # 获取原点
        orgs = y - B * self.output_shape[1] * self.image_spacing[1] / 2 - N * self.output_shape[
            0] * self.image_spacing[0] / 2
        # 获取方向矩阵，x方向为副法线方向，y方向为法线方向，z方向为切线方向
        dirs = np.concatenate([B, N, T], axis=1).reshape([-1, 3,
                                                          3]).transpose([0, 2, 1])
        # 获取方向上的spacing
        spacing = np.diag((self.image_spacing[0], self.image_spacing[1], 1.0))
        return orgs, dirs, spacing

    # 重采样
    def _resample(
            self,
            transform: toty.SitkTransformType,
            origin: toty.NumericArrayType,
            nominal_spacing: toty.NumericArrayType,
            result_spacing: toty.NumericArrayType,
            direction: toty.NumericArrayType,
            size: toty.NumericArrayType,
            default_value: Optional[toty.Numeric] = None,
            return_numpy_array: bool = False,
            squeeze_d_axis: bool = True,
    ) -> Union[sitk.Image, np.ndarray]:
        if default_value is None:
            default_value = self.default_value
        res_image = sitk.Resample(
            self.image_data,
            np.array(size).tolist(),
            transform,
            self.sitk_interpolator,
            np.array(origin).tolist(),
            np.array(nominal_spacing).tolist(),
            np.array(direction).ravel().tolist(),
            default_value,
            self.image_data.GetPixelID(),
        )
        res_image.SetSpacing(result_spacing)
        if size[-1] == 1 and squeeze_d_axis:
            res_image = res_image[:, :, 0]
        if return_numpy_array:
            return sitk.GetArrayFromImage(res_image)
        else:
            return res_image
