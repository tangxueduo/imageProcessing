from typing import Dict, Sequence, Union

import numpy as np
import SimpleITK as sitk


Numeric = Union[int, float]
NumericArrayType = Union[np.ndarray, Sequence[Numeric]]
CenterlineDictType = Dict[str, Union[float, NumericArrayType]]
CenterlineType = Union["Centerline", CenterlineDictType]
SitkTransformType = Union[
    sitk.Transform, sitk.AffineTransform, sitk.Euler3DTransform, sitk.DisplacementFieldTransform,
]
