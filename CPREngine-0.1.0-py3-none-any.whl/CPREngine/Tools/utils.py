from typing import Sequence, Union

import numpy as np
import SimpleITK as sitk

from CPREngine.Tools.type_base import Numeric, NumericArrayType


def array_polyfiller(item: Union[Numeric, NumericArrayType], array_len=2) -> Sequence[Numeric]:
    if not isinstance(item, (np.ndarray, list, tuple)):
        return [item,] * array_len
    else:
        return list(item)


def convert_grid_to_dft(grid):
    dft_size = grid.shape[:-1][::-1]
    dft_pnts = np.stack(np.meshgrid(*[np.arange(i) for i in dft_size], indexing="ij")).transpose([3, 2, 1, 0])
    return grid - dft_pnts


def convert_dft_to_grid(dft):
    df = sitk.GetArrayFromImage(dft.GetDisplacementField())
    dft_size = dft.shape[:-1][::-1]
    dft_pnts = np.stack(np.meshgrid(*[np.arange(i) for i in dft_size], indexing="ij")).transpose([3, 2, 1, 0])
    df += dft_pnts
    return df
