import json
from CPREngine.ImageRender import probe_render as render
from enum import Enum


class Tasktype(Enum):
    PROBE = 1            # 探针
    STRETCHEDCPR = 2     # 拉伸cpr
    STRAIGHTENEDCPR = 3  # 拉直cpr

def _ProbeProcess(data_param, image_param, centerlin_param):
    probe_indexs = data_param["probe_info"]["probe_indexs"]
    centerline = {'y': centerlin_param['y'][probe_indexs],
                  'B': centerlin_param['B'][probe_indexs],
                  'N': centerlin_param['N'][probe_indexs],
                  'T': centerlin_param['T'][probe_indexs]}
    probe_render = render.ProbeRender(centerline=centerline, image_data=image_param,
                                      image_spacing=data_param["probe_info"]["spacing"],
                                      output_shape=data_param["probe_info"]["shape"])
    return probe_render.Probe()


def _StretchedcprProcess(data_param, image_param, centerlin_param):
    print("Stretchedcpr")

def _StraightenedcprProcess(data_param, image_param, centerlin_param):
    print("Straightenedcpr")

def _ControlProcess(condition, data_param=None, image_param=None, centerlin_param=None):
    functions = {
        Tasktype.PROBE: _ProbeProcess,
        Tasktype.STRETCHEDCPR: _StretchedcprProcess,
        Tasktype.STRAIGHTENEDCPR: _StraightenedcprProcess
    }
    return functions.get(Tasktype(condition), lambda: None)(data_param, image_param, centerlin_param)

def CPRProcess(json_data, image_data, centerline):
    try:
        data = json.loads(json_data)
        task_type = data["task_type"]
        return _ControlProcess(task_type, data, image_data, centerline)

    except json.JSONDecodeError as e:
        print("CPRProcess JSON decoding error:", e.msg)
        print("Line:", e.lineno)
        print("Column:", e.colno)

